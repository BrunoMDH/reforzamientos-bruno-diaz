#5.Crear un programa que inicia creando un sueldo en una variable, sepamos si
#es par o impar mediante un mensaje. Utilizar módulo y condicional (if).

sueldo = 3222
if sueldo % 2 == 0:
    print("El sueldo es par")
if sueldo % 2 == 1:
    print("El sueldo es impar")