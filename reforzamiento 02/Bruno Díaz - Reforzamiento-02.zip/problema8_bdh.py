#8.Usando la condicional if imprimir por pantalla si una lista ([]) está vacía o
#no, comprobar con una lista vacía y otra con una lista con dato al menos
#([dato_1, dato_2]).

var1 = []
var2 = ["Bruno", "Díaz"]

if var1:
    print("La lista var1 no está vacía")
if not var1:
    print("La lista var1 está vacía")

if var2:
    print("La lista var2 no está vacía")
if not var2:
    print("La lista var2 está vacía")
