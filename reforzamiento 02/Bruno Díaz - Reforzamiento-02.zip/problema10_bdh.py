#10. Crear un programa que tome un número flotante en una
#variable con 6 decimales y se imprima de diferentes modos:
#- 1 decimal
#- 2 decimales
#- 4 decimales

var1 = 823.356232
print("1 decimal: {:.1f}".format(var1))
print("2 decimales: {:.2f}".format(var1))
print("4 decimales: {:.4f}".format(var1))