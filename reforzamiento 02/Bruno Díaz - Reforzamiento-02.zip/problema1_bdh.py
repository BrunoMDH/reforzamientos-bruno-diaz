#1. El valor de ‘¡HI TuNombre Apellido!’ imprimirlo en consola, el texto
#debe ser un string y deberás guardarlo en una variable llamada mi_saludo.
#Tu nombre completo debe estar en otra variable.
nombre_completo = "Bruno Miguel Díaz Huallullo"
print("¡HI {}!".format(nombre_completo))
