# Escribe un programa que convierta cierta cantidad de soles a
# dólares, usando un tipo de cambio que se proporciona en el
# programa.
# Estos valores estarán dentro de sus variables respectivamente.
# La salida mostrará tres cambios que hagas respectivamente de
# tres montos a convertir.

tipo_cambio = 4.5

monto1 = 322
monto2 = 450
monto3 = 951

print("{} soles = {:.2f} dólares".format(monto1, monto1/tipo_cambio))
print("{} soles = {:.2f} dólares".format(monto2, monto2/tipo_cambio))
print("{} soles = {:.2f} dólares".format(monto3, monto3/tipo_cambio))
