# Crea un programa que tome un número decimal (con 6 número
# en la parte decimal) e imprima ese número con:
# 1 decimal, 2 decimales y 4 decimales

numero = 3.146754

print("1 decimal: {:.1f}".format(numero))
print("2 decimales: {:.2f}".format(numero))
print("4 decimales: {:.4f}".format(numero))
