# Convertir tu diccionario a una lista y mostrar en consola el tipo de datos
# final que tienes.
persona = {"nombre": "Bruno","salario": 2500,"dni": "75349971"}

lista_persona = list(persona.values())
print(lista_persona)

print(type(lista_persona))
